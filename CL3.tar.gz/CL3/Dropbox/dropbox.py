import Tkinter
import os
import sys


def mk_dir():
	print "Creating Directory"
	dirname = raw_input("Enter the name of directory : ")
	os.system("bash ~/ritesh_codes/new_cloud/cloudcodes/B_C2_Storage/Dropbox-Uploader-master/dropbox_uploader.sh mkdir "+dirname+" ")
	
def rm_dir():
	print "Delete Directory"
	dirname = raw_input("Enter the name of directory : ")
	os.system("bash ~/ritesh_codes/new_cloud/cloudcodes/B_C2_Storage/Dropbox-Uploader-master/dropbox_uploader.sh delete "+dirname+" ")

def display():
	print "List"
	dirname = raw_input("Enter the name of directory : ")
	os.system("bash ~/ritesh_codes/new_cloud/cloudcodes/B_C2_Storage/Dropbox-Uploader-master/dropbox_uploader.sh list")

def up_dir():
	print "Uploading Directory"
	dirname = raw_input("Enter the filepath : ")
	os.system("sudo bash ~/ritesh_codes/new_cloud/cloudcodes/B_C2_Storage/Dropbox-Uploader-master/dropbox_uploader.sh upload try"+dirname+" ")

def down_dir():
	print "Download Directory"
	dirname = raw_input("Enter the name of directory : ")
	os.system("sudo bash ~/ritesh_codes/new_cloud/cloudcodes/B_C2_Storage/Dropbox-Uploader-master/dropbox_uploader.sh download /a.txt try"+dirname+" ")

def exitapp():
	exit(0)



class TkinterApp(Tkinter.Tk):
	def __init__(self,parent):
		Tkinter.Tk.__init__(self)
		self.parent=parent
		self.initialise()
		
		
		
	def initialise(self):
		self.grid()
		
		button = Tkinter.Button(self, text = "Create Directory", command = mk_dir)
		button.grid(column = 1, row = 2)
		
		button = Tkinter.Button(self, text = "Delete Directory", command = rm_dir)
		button.grid(column = 1, row = 4)
		
		button = Tkinter.Button(self, text = "Download", command = down_dir)
		button.grid(column = 1, row = 6)

		button = Tkinter.Button(self, text = "Upload", command = up_dir)
		button.grid(column = 1, row = 8)
		
		button = Tkinter.Button(self, text = "List", command = display)
		button.grid(column = 1, row = 10)
		
		button = Tkinter.Button(self, text = "Exit", command = exitapp)
		button.grid(column = 1, row = 12)		

if __name__=='__main__':
	app = TkinterApp(None)
	app.title("Dropbox Operations")
	app.mainloop()
